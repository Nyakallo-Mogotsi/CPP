#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    cout << "Assignment  1\n" << endl;

    int thisYear = 2022;
    int yearOfBirth = 0;

    cout << "Enter your year of birth (4 digits): ";
    cin >> yearOfBirth;



    while ((yearOfBirth < 1000) || (yearOfBirth > 9999) || (yearOfBirth >= 2022))
    {
        cout << yearOfBirth << " is invalid.Try again."<<endl;
        cout << "Enter your year of birth (4 digits): ";
        cin >> yearOfBirth;
    }

    if(yearOfBirth % 400 ==0 && yearOfBirth % 100 == 0)
    {
        cout << yearOfBirth << " was a leap year.\n" << endl;
    }
    else if (yearOfBirth % 4 == 0 && yearOfBirth % 100 != 0)
    {
        cout << yearOfBirth << " was a leap year.\n" << endl;
    }
    else
    {
        cout << yearOfBirth << " was not a leap year.\n";
    }

 int age = thisYear-yearOfBirth;

    cout << "\nYou are " << age << " years old." <<endl;

    if(yearOfBirth <= 1945)
    {
        printf("You belong to the silent generation.");
    }
    else if (yearOfBirth >= 1945 && yearOfBirth <= 1964)
    {
        printf("You are a Baby Boomer.");
    }
    else if (yearOfBirth >= 1965 && yearOfBirth <= 1976)
    {
        printf("You belong to Generation X.");
    }
    else if (yearOfBirth >= 1977 && yearOfBirth <= 1995)
    {
        printf("You belong to Generation Y.");
    }
    else if (yearOfBirth >= 1996 && yearOfBirth <= 2015)
    {
        printf("You belong to Generation Z.");
    }
    else
    {
        printf("Your generation is still uncatagorized.\n");
    }

    printf("\n\nDone!\n");
    return 0;
}
