#include <iostream>
#include <stdio.h>

using namespace std;

int main()
{
    int choice;
    double BMI=0 , weight=0 , height=0;
    string status= " ";

    cout << "BMI calculator\n\n1.Weight in pounds, height in inches\n"
         << "2. Weight in kilograms, height in meters"<<endl;

    cin >> choice;

    while((choice !=1 ) && (choice!=2))
    {
        cout << "Invalid choice. Please enter a valid choice: ";

        cin >> choice;

    }

    if(choice == 1)
    {

    //pounds and inches

        cout << "weight in pounds: ";
        cin >> weight;
        cout << "height in inches: ";
        cin >> height;

    // Calculate BMI

        BMI = (weight * 703) / (height * height);

    //print

        printf("\n\nResult...............\n\nWeight: %.2lf pounds",weight);
        printf(" \nHeight: %.2lf inches" , height);
        printf(" \nBMI: %.1lf",BMI);
    }
    else if (choice == 2)
    {

    //kilograms and meters

        cout << "weight in kilograms: ";
        cin >> weight;
        cout << "height in meters: ";
        cin >> height;

    // Calculate BMI

        BMI = (weight) / (height * height);

    //print

        printf("\n\nResult...............\n\nWeight: %.2lf kilograms",weight);
        printf(" \nHeight: %.2lf meters" , height);
        printf(" \nBMI: %.1lf",BMI);

    }

    if(BMI >= 30)
    status = "obese";
    else if (BMI >= 25)
    status = "overweight";
    else if (BMI >= 18.5)
    status = "normal";
    else
    status = "underweight";

    cout << "\nstatus: " << status << endl;

    return 0;
}
