#include <iostream>

using namespace std;

int main()
{
    char answer = ' ' ;
    int choice;
    cout << "Fun run Competition\n" << endl;

    cout << "Do you want to register a participant (Y or N): " << endl;
    cin >> answer;

    cout << "Categories: \n1. 5 Kilometers\n2. 10 Kilometers\n3. 15 Kilometers" << endl;

    cout << "Your choice (1/2/3): " << endl;
    cin >> choice;

    if (choice<1 || choice>3)
    {
        cout << "\nInvalid choice\nRegistration Cancelled." << endl;
    }

    while (answer == 'y' || answer == 'Y' )
    {
         cout << "Do you want to register another participant (Y or N): " << endl;
         cin >> answer;

         cout << "Categories: \n1. 5 Kilometers\n2. 10 Kilometers\n3. 15 Kilometers" << endl;

         cout << "Your choice (1/2/3): " << endl;
         cin >> choice;
    }

     if (answer == 'n' || answer == 'N')
     {
         cout << "registrations per category" << endl;


     }



    return 0;
}
