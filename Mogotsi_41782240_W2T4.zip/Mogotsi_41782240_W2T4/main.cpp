#include <iostream>
#include <string>

using namespace std;

int main()
{
    int val1, val2, choice;
    double answer;
    string operation,output;

    cout << "Calculator.\n" << endl;

    cout << "Enter value 1: ";
    cin >> val1;

    cout << "Enter value 2: ";
    cin >> val2;

    cout << "Operation.\n" << endl
         << "1. Addition.\n"
         << "2. Subtraction.\n"
         << "3. Multiplication.\n"
         << "4. Division.\n"
         << "5. None.\n";

    cin >> choice;

    switch(choice)
    {
        case 1:
            operation = "Addition";
            answer = val1 + val2;
            output = "Output: " + to_string(val1) + " + " + to_string(val2) + " = " ;
            break;

        case 2:
            operation = "Subtraction";
            answer = val1 - val2;
            output = "Output: " + to_string(val1) + " - " + to_string(val2) + " = ";
            break;

        case 3:
            operation = "Multiplication";
            answer = val1 * val2;
            output = "Output: " + to_string(val1) + " * " + to_string(val2) + " = ";
            break;

        case 4:
            operation = "Division";
            answer = (double)val1 / val2;
            output = "Output: " + to_string(val1) + " / " + to_string(val2) + " = ";
            break;

        default:
            operation = "none";
            output = "none\t" ;
            answer = 0.0;
    }

    cout << output << answer << endl;



    return 0;
}
