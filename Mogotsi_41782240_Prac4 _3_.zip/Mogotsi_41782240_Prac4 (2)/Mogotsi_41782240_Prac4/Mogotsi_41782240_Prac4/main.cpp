#include <iostream>
#include <iomanip>
#include <stdio.h>
#include <string>

using namespace std;

struct Restaurant
{
    char name[30];
    int food;
    int service;
};

void displayData(Restaurant arrR[],int c )
{
    cout << "List of Restaurants.\n" << endl;
    printf("%-10s %-15s %-15s %-15s\n", " " , "Name" , "Food" , "Service");

    for (int k = 0 ; k < c ; k++)
    {
        printf("%-10d %-15s %-15d %-15d\n", k+1 , arrR[k].name , arrR[k].food , arrR[k].service );
    }
}


int main()
{
    const int SIZE = 12;
    Restaurant arrRestaurant[12];
    int counter=0;

    cout << "Enter the name of a restuarant (X to quit) :" ;
    cin >> arrRestaurant[counter].name;

    while (toupper(arrRestaurant[counter].name[0]) != 'X')
    {

        cout << "Enter the rating for food (1 to 10): ";
        cin >> arrRestaurant[counter].food;

        cout << "Enter the rating for service (1 to 10): ";
        cin >> arrRestaurant[counter].service;

        cout << "Enter the name of a restuarant (X to quit) :" ;
        cin >> arrRestaurant[counter].name;

    }

    displayData(arrRestaurant,counter);

    int num = 0;
    cout << "Enter a number from the list: " << endl;
    cin >> num;


    cout << "Name of restaurant: " << arrRestaurant[num-1].name << endl;
    cout << "Current ratings: " << endl;
    cout << "Food and ratings: " <<  endl;
    cout << "Food: " << arrRestaurant[num-1].food << endl;
    cout << "Service: " << arrRestaurant[num-1].service << endl;

    cout << "Enter the new rating for food out of 10: " << endl;
    cin >> arrRestaurant[num-1].food;

    cout << "Enter the new rating for food out of 10: " << endl;
    cin >> arrRestaurant[num-1].service;

    displayData(arrRestaurant,counter);





    return 0;
}
