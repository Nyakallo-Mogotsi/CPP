#include <iostream>
#include <fstream>
#include <stdio.h>
#include <string>

using namespace std;

struct Book
{
    string title;
    char type;
    int ratings[3];
};

void displayData(Book arrB[], int c)
{
    cout << "\nList of books: " << endl;

    printf("%-28s %-15s %-12s\n", "Title", "Type", "Ratings");

    for(int k = 0; k < c; k++)
    {
        string type = "";

        switch(arrB[k].type)
        {
        case 'F':
            type = "Fiction";
            break;
        case 'N':
            type = "Non-Fiction";
            break;
        default:
            type = "Unknown";
            break;
        }

        printf("%-2d %-25s %-15s %-5d %-5d %-5d\n", (k+1), arrB[k].title.c_str(), type.c_str(), arrB[k].ratings[0], arrB[k].ratings[1], arrB[k].ratings[2]);
    }
}

int determineHighestRating(Book arrB[], int count, double &average)
{
    double total = 0;
    double temp = 0;
    int index;

    for(int k = 0; k < count; k++)
    {
        total = 0;

        for(int j = 0; j < 3; j++)
        {
            total += arrB[k].ratings[j];
        }
        average = total / 3;

        if(average > temp)
        {
            index = k;
            temp = average;
        }
    }

    average = temp;
    return index;
}


//    Book book1, book2, book3, book4, book5, book6;
//
//    book1.title = "The Hobbit";
//    book1.type = 'F';
//    book1.ratings[0] = 9;
//    book1.ratings[1] = 8;
//    book1.ratings[2] = 8;
//
//    book2.title = "Animal Farm";
//    book2.type = 'F';
//    book2.ratings[0] = 8;
//    book2.ratings[1] = 8;
//    book2.ratings[2] = 8;
//
//    book3.title = "The Great Gatsby";
//    book3.type = 'F';
//    book3.ratings[0] = 7;
//    book3.ratings[1] = 8;
//    book3.ratings[2] = 8;
//
//    book4.title = "A Brief History of Time";
//    book4.type = 'N';
//    book4.ratings[0] = 9;
//    book4.ratings[1] = 7;
//    book4.ratings[2] = 8;
//
//    book5.title = "Hiroshima";
//    book5.type = 'N';
//    book5.ratings[0] = 7;
//    book5.ratings[1] = 8;
//    book5.ratings[2] = 7;
//
//    book6.title = "Anne Frank: Diary";
//    book6.type = 'N';
//    book6.ratings[0] = 7;
//    book6.ratings[1] = 8;
//    book6.ratings[2] = 5;
//
//    Book arrBooks[SIZE] = {book1, book2, book3, book4, book5, book6};

int main()
{
    const int SIZE = 10;
    int count = 0;
    Book arrBooks[SIZE];

    string temp1, temp2;

    fstream inFile;
    inFile.open("BookInfo.txt");

    if(inFile.fail())
    {
        cerr << "Error reading file!" << endl;
    }
    else
    {
        while(!(inFile.eof()))
        {
            getline(inFile, arrBooks[count].title);

            getline(inFile, temp2);
            arrBooks[count].type = temp2[0];

            getline(inFile,temp1);

            for(int k = 0; k < 3; k++)
            {
                arrBooks[count].ratings[k] = temp1[k] - '0';
            }

//              ALTERNATIVE TO THE ABOVE FOR LOOP - HARD CODING
//            arrBooks[count].ratings[0] = temp1[0] - '0';
//            arrBooks[count].ratings[1] = temp1[1] - '0';
//            arrBooks[count].ratings[2] = temp1[2] - '0';

            count++;
        }
        cout << "\nData read from text file successfully!" << endl;

        inFile.close();
    }

    displayData(arrBooks, count);

    int index;
    char answer;

    do
    {
        cout << "\nEnter a number from the list: ";
        cin >> index;

        cout << "\nBook title: " << arrBooks[index-1].title << endl;
        cout << "      Current Ratings" << endl;
        cout << "      ---------------" << endl;

        for(int k = 0; k < 3; k++)
        {
            cout << "Rating " << (k+1) << ": ";
            cin >> arrBooks[index-1].ratings[k];

            while(arrBooks[index-1].ratings[k] < 1 || arrBooks[index-1].ratings[k] > 9)
            {
                cout << "***INVALID input!  Rating must be in range of 1 - 9!  TRY AGAIN***" << endl;
                cout << "Rating " << (k+1) << ": ";
                cin >> arrBooks[index-1].ratings[k];
            }
        }

        displayData(arrBooks, count);

        cout << "\nDo you want to change the rating for another book? (Y/N): ";
        cin >> answer;
    }
    while(toupper(answer) == 'Y');

    double avg = 0;

    int highPos = determineHighestRating(arrBooks, count, avg);

    cout << "\nBest Rated Book : " << arrBooks[highPos].title << endl;
    printf("Average rating: %-5.1lf", avg);
    cout << endl << endl;


    return 0;
}
