#include <iostream>
#include <stdlib.h>
#include <time.h>
#include <fstream>

using namespace std;

void populateArray(int* pRain, int* pCount)
{
    srand(time(0));

    for(int k = 0; k < *pCount; k++)
    {
        *(pRain + k) = rand()%31 + 15;
    }
}

void displayRainFall(int* pRain, int* pCount)
{
    cout << "List of temperatures" << endl;

    for(int k = 0; k < *pCount; k++)
    {
        cout << *(pRain + k) << endl;
    }
}

void findLowestTemp(int* pRain, int* pCount, int* index)
{
    int lowest = *(pRain);

    for(int k = 0; k < *pCount; k++)
    {
        if(*(pRain + k) < lowest)
        {
            lowest = *(pRain + k);
            *index = k;
        }
    }
}

int main()
{
    const int SIZE = 10;
    int arrRain[SIZE];
    int count = 10;

    int* pRain = arrRain;
    int* pCount = &count;

    int index = 0;
    int* pIndex = &index;

    double average = 0;

    populateArray(pRain, pCount);
    displayRainFall(pRain, pCount);
    findLowestTemp(pRain, pCount, pIndex);

    ofstream outfile;
    outfile.open("lowestTemp.txt");

    outfile << "The lowest temperature was on day " << *pIndex + 1 << " with a temperature of " << *(pRain + *pIndex) << endl;

    cout << "\nData saved to text file!" << endl;

    outfile.close();

    return 0;
}
