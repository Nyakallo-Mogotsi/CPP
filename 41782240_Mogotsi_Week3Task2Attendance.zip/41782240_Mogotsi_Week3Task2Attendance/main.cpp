#include <iostream>
//#include <ctime>
#include <time.h>
//#include <stdlib.h>

using namespace std;

int main()
{
    char symbol = 'A';
    const int SIZE = 20;
    int arrMarks[SIZE];
    int arrCount[6] = {0,0,0,0,0,0};  //int countA, countB, countC = 0;
    int* pMarks = arrMarks;
    int* pCount = arrCount;
    srand(time(0));

    for(int k = 0; k < SIZE; k++)
    {
        *(pMarks + k) = rand() % 101;//0 to 100   //10 + (rand() % 91); //10 to 100

        if(*(pMarks + k) >= 85)
        {
            *pCount++; // countA++;
        }
        else if(*(pMarks + k) >= 70)
            (*(pCount + 0))++;
        else if(*(pMarks + k) >= 60)
            (*(pCount + 1))++;
        else if(*(pMarks + k) >= 50)
            (*(pCount + 2))++;
        else if(*(pMarks + k) >= 35)
            (*(pCount + 3))++;
        else
            (*(pCount + 4))++;
    }

    cout << "Marks" << endl;

    for(int k = 0; k < SIZE; k++)
    {
        cout << (*pMarks + k) << "  ";
    }

    cout << "\n\nNumber of symbols" << endl;

    for(int k = 0; k < 6; k++)
    {
        cout << symbol << " symbols: " << (*pCount + k) << endl;
        symbol++; // A -> B
    }

    //cout << "\nA symbols: " << countA << endl;
    //cout << "B symbols: " << countB << endl;
    //cout << "C symbols: " << arrCount[2] << endl;
    //cout << "D symbols: " << arrCount[3] << endl;
    //cout << "E symbols: " << arrCount[4] << endl;
    //cout << "F symbols: " << arrCount[5] << endl;


    return 0;
}
